# Register & Prepare all the base resources
$RESOURCE_GROUP="AksEstsR" #Name this whatever you want 
az group create --name $RESOURCE_GROUP --location eastus
az extension add --name aks-preview
az extension update --name aks-preview
az feature register --namespace "Microsoft.ContainerService" --name "EnableWorkloadIdentityPreview"
az feature show --namespace "Microsoft.ContainerService" --name "EnableWorkloadIdentityPreview"
az provider register --namespace Microsoft.ContainerService

# Setup AKS Cluster
$CLUSTER="myAksCluster"
az aks create -g $RESOURCE_GROUP -n $CLUSTER --node-count 1 --enable-oidc-issuer --enable-workload-identity --generate-ssh-keys
$AKS_OIDC_ISSUER="$(az aks show -n $CLUSTER -g $RESOURCE_GROUP --query "oidcIssuerProfile.issuerUrl" -otsv)"

# Enviroment Variables
# environment variables for the Azure Key Vault resource
$KEYVAULT_NAME="aksestsr-thomasbraun" #Give this a unique name
$KEYVAULT_SECRET_NAME="my-secret"
$LOCATION="westcentralus"
# environment variables for the Kubernetes Service account & federated identity credential
$SERVICE_ACCOUNT_NAMESPACE="default"
$SERVICE_ACCOUNT_NAME="workload-identity-sa"
# environment variables for the Federated Identity
$SUBSCRIPTION="e6fca86a-dba8-40ea-b214-cd5caafb4ae8" #Replace with your subcription ID
# user assigned identity name
$UAID="fic-test-ua"
# federated identity name
$FICID="fic-test-fic-name"

# Setup keyvault, secret, & managed identity
az keyvault create --resource-group "${RESOURCE_GROUP}" --location "${LOCATION}" --name "${KEYVAULT_NAME}"
$KEYVAULT_URL="$(az keyvault show -g ${RESOURCE_GROUP} -n ${KEYVAULT_NAME} --query properties.vaultUri -o tsv)"
az account set --subscription "${SUBSCRIPTION}"
az identity create --name "${UAID}" --resource-group "${RESOURCE_GROUP}" --location "${LOCATION}" --subscription "${SUBSCRIPTION}"
$USER_ASSIGNED_CLIENT_ID="$(az identity show --resource-group "${RESOURCE_GROUP}" --name "${UAID}" --query 'clientId' -otsv)"
az keyvault set-policy --name "${KEYVAULT_NAME}" --secret-permissions get --spn "${USER_ASSIGNED_CLIENT_ID}"
az keyvault secret set --vault-name "${KEYVAULT_NAME}" --name "${KEYVAULT_SECRET_NAME}" --value 'Hello!' ## Creates and sets the secret
az aks get-credentials -n $CLUSTER -g "${RESOURCE_GROUP}"


## federation.yml work
code federation.yml
## Paste yml into file and save w/ ctrl + s
kubectl apply -f federation.yml

# This has to be executed after the service account is deployed in the AKS cluster
az identity federated-credential create --name ${FICID} --identity-name ${UAID} --resource-group ${RESOURCE_GROUP} --issuer ${AKS_OIDC_ISSUER} --subject system:serviceaccount:${SERVICE_ACCOUNT_NAMESPACE}:${SERVICE_ACCOUNT_NAME}

## workload.yml work
code workload.yml
## Paste yml into file and save w/ ctrl + s
kubectl apply -f workload.yml

kubectl describe pod sample-workload
kubectl logs sample-workload # Runs workload and records logs
## Should just print out the Secret!

# Delete all the resources
az group delete --name $RESOURCE_GROUP